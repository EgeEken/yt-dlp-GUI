import tkinter as tk
from tkinter import ttk, messagebox
import subprocess

class YTDLPGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("yt-dlp GUI")
        self.geometry("500x400")
        self.resizable(False, False)

        self._build_ui()

    def _build_ui(self):
        # URL input
        ttk.Label(self, text="Video / Playlist URL:").pack(anchor="w", padx=10, pady=(10, 0))
        self.url_entry = ttk.Entry(self, width=60)
        self.url_entry.pack(padx=10, pady=5)

        # File type selector
        ttk.Label(self, text="Output format:").pack(anchor="w", padx=10, pady=(10, 0))

        self.format_var = tk.StringVar(value="mp3")
        frame = ttk.Frame(self)
        frame.pack(anchor="w", padx=10)

        ttk.Radiobutton(frame, text="MP3 (audio)", variable=self.format_var, value="mp3").grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(frame, text="MP4 (video)", variable=self.format_var, value="mp4").grid(row=1, column=0, sticky="w")
        ttk.Radiobutton(frame, text="Custom", variable=self.format_var, value="custom").grid(row=2, column=0, sticky="w")

        self.custom_format = ttk.Entry(frame, width=10)
        self.custom_format.grid(row=2, column=1, padx=5)
        self.custom_format.insert(0, "mkv")

        # Advanced settings
        self.advanced_frame = ttk.LabelFrame(self, text="Advanced settings")
        self.advanced_frame.pack(fill="x", padx=10, pady=15)

        self.embed_thumb = tk.BooleanVar()
        self.embed_meta = tk.BooleanVar()

        ttk.Checkbutton(self.advanced_frame, text="Embed thumbnail", variable=self.embed_thumb).pack(anchor="w", padx=10, pady=2)
        ttk.Checkbutton(self.advanced_frame, text="Embed metadata", variable=self.embed_meta).pack(anchor="w", padx=10, pady=2)

        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(pady=20)

        ttk.Button(btn_frame, text="Download", command=self.download).grid(row=0, column=0, padx=10)
        ttk.Button(btn_frame, text="Quit", command=self.destroy).grid(row=0, column=1, padx=10)

    def download(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a URL")
            return

        fmt = self.format_var.get()
        cmd = ["yt-dlp"]

        if fmt == "mp3":
            cmd += ["-x", "--audio-format", "mp3"]
        elif fmt == "mp4":
            cmd += ["-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]"]
        else:
            ext = self.custom_format.get().strip()
            if not ext:
                messagebox.showerror("Error", "Custom format is empty")
                return
            cmd += ["--recode-video", ext]

        if self.embed_thumb.get():
            cmd.append("--embed-thumbnail")
        if self.embed_meta.get():
            cmd += ["--add-metadata", "--embed-metadata"]

        cmd.append(url)

        try:
            subprocess.Popen(cmd)
            messagebox.showinfo("Started", "Download started in background")
        except FileNotFoundError:
            messagebox.showerror("Error", "yt-dlp not found in PATH")
        except Exception as e:
            messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    app = YTDLPGUI()
    app.mainloop()
